import argparse
from aventura_pkg.labirinto import criar_labirinto, imprimir_labirinto

def encontrar_entrada(labirinto):
    """Encontra a posição da entrada 'E' no labirinto."""
    for y, linha in enumerate(labirinto):
        for x, celula in enumerate(linha):
            if celula == 'E':
                return (x, y)  # Retorna a posição (x, y) da entrada
    return None  # Retorna None se não encontrar a entrada

def mostrar_instrucoes():
    """Mostra as instruções do jogo."""
    print("Bem-vindo à Aventura no Labirinto!")
    print("Instruções:")
    print("1. Você começará na posição marcada como 'E'.")
    print("2. O objetivo é chegar à posição marcada como 'S'.")
    print("3. Use as teclas 'w', 'a', 's', 'd' para mover (cima, esquerda, baixo, direita).")
    print("4. Não encoste nas paredes representadas por '#'.")
    print("5. Boa sorte!\n")

def iniciar_jogo(dificuldade, nome_jogador):
    """Inicia o jogo com base na dificuldade e no nome do jogador."""
    labirinto = criar_labirinto(dificuldade)
    posicao_entrada = encontrar_entrada(labirinto)

    if posicao_entrada is None:
        print("Erro: Entrada não encontrada no labirinto!")
        return

    jogador = {'nome': nome_jogador, 'posicao': posicao_entrada}  # Posição inicial do jogador é a entrada
    mostrar_instrucoes()  # Mostra as instruções do jogo

    while True:
        imprimir_labirinto(labirinto, jogador['posicao'])
        movimento = input("Movimento (w/a/s/d) ou 'q' para sair: ").strip().lower()

        if movimento == 'q':
            print("Saindo do jogo. Até mais!")
            break
        
        # Verifica a nova posição com base no movimento
        nova_posicao = jogador['posicao']
        if movimento == 'w':  # Cima
            nova_posicao = (jogador['posicao'][0], jogador['posicao'][1] - 1)
        elif movimento == 'a':  # Esquerda
            nova_posicao = (jogador['posicao'][0] - 1, jogador['posicao'][1])
        elif movimento == 's':  # Baixo
            nova_posicao = (jogador['posicao'][0], jogador['posicao'][1] + 1)
        elif movimento == 'd':  # Direita
            nova_posicao = (jogador['posicao'][0] + 1, jogador['posicao'][1])

        # Verifica se a nova posição é válida
        x, y = nova_posicao
        if (0 <= x < len(labirinto[0]) and 0 <= y < len(labirinto)):
            if labirinto[y][x] == '#':
                print("Game Over! Você colidiu com uma parede!")
                break
            elif labirinto[y][x] == 'S':
                print("Parabéns, você chegou à saída! Você venceu!")
                break
            else:
                jogador['posicao'] = nova_posicao  # Atualiza a posição do jogador
        else:
            print("Movimento inválido! Tente novamente.")

def main():
    parser = argparse.ArgumentParser(description='Aventura no Labirinto')
    parser.add_argument('--name', type=str, required=True, help='Nome do jogador')
    parser.add_argument('--dificuldade', type=str, choices=['facil', 'medio', 'dificil'], required=True, help='Dificuldade do jogo')
    
    args = parser.parse_args()
    iniciar_jogo(args.dificuldade, args.name)

if __name__ == "__main__":
    main()
