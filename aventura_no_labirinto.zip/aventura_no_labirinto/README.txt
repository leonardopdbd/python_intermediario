
# Aventura no Labirinto

## Descrição
"Aventura no Labirinto" é um jogo de exploração em um labirinto via terminal. Os jogadores navegam por um labirinto desafiador e encontram obstáculos em sua jornada. O jogo utiliza recursos da biblioteca `rich` para formatação de texto e da biblioteca `pynput` para leitura do teclado.

## Requisitos
Antes de executar o jogo, certifique-se de que você tenha o Python 3.x instalado em sua máquina. Além disso, você precisará instalar as seguintes bibliotecas:

- `rich`
- `pynput`

Você pode instalar as bibliotecas necessárias usando o `pip`:

pip install rich pynput
Como executar o jogo
Clone o repositório ou baixe o arquivo ZIP:


git clone https://github.com/leonardopdbd/python_intermediario.git
cd python_intermediario
ou, se você baixou o arquivo ZIP, extraia o conteúdo em um diretório de sua escolha.

Navegue até o diretório do jogo:



cd aventura_no_labirinto
Ative seu ambiente virtual (opcional, mas recomendado):

Se você estiver usando um ambiente virtual, ative-o. Por exemplo:

No Windows:


Copiar código
.\venv\Scripts\activate

No macOS/Linux:


Copiar código
source venv/bin/activate
Execute o jogo:

Para iniciar o jogo, execute o seguinte comando:


Copiar código
python main.py
Controles do jogo:

Use as teclas de seta do teclado para navegar pelo labirinto.
Siga as instruções exibidas no terminal para interagir com o jogo.
Iniciando o Jogo
Após executar o comando python main.py, o jogo será iniciado. Você verá a tela de introdução e as instruções de como jogar. Utilize as teclas de seta para mover seu personagem pelo labirinto.



