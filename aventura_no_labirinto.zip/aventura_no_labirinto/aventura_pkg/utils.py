# utils.py
from rich.console import Console

console = Console()

def imprime_instrucoes():
    """Imprime as instruções do jogo."""
    console.print("[bold blue]Bem-vindo ao jogo Aventura no Labirinto![/bold blue]")
    console.print("Use as teclas [bold]W[/bold], [bold]A[/bold], [bold]S[/bold], [bold]D[/bold] para mover o jogador.")
    console.print("[green]Colete itens e evite armadilhas no labirinto![/green]")

def imprime_menu():
    """Imprime o menu principal do jogo."""
    console.print("[bold]Menu Principal:[/bold]")
    console.print("1. Jogar")
    console.print("2. Instruções")
    console.print("3. Sair")
