def criar_labirinto(dificuldade):
    """Cria um labirinto com base na dificuldade escolhida."""
    if dificuldade == "facil":
        labirinto = [
            "##########",
            "# E      #",
            "#        #",
            "#   #    #",
            "# ### ### #",
            "#         #",
            "# ### ### #",
            "# S      #",
            "##########"
        ]
    elif dificuldade == "medio":
        labirinto = [
            "##########",
            "# E  #   #",
            "#    # # #",
            "# #  #   #",
            "# ### ### #",
            "#         #",
            "# # ### # #",
            "#       S #",
            "##########"
        ]
    elif dificuldade == "dificil":
        labirinto = [
            "##########",
            "# E #    #",
            "# # # ## #",
            "#   #    #",
            "# # ######",
            "# #      #",
            "# ###### #",
            "#      S #",
            "##########"
        ]
    else:
        raise ValueError("Dificuldade inválida! Use 'facil', 'medio' ou 'dificil'.")  # Erro mais claro

    return [list(linha) for linha in labirinto]  # Retorna uma lista de listas

def imprimir_labirinto(labirinto, posicao_jogador):
    """Imprime o labirinto com a posição do jogador."""
    labirinto_visual = [linha.copy() for linha in labirinto]  # Cria uma cópia do labirinto

    x, y = posicao_jogador
    if 0 <= x < len(labirinto[0]) and 0 <= y < len(labirinto):
        labirinto_visual[y][x] = 'P'  # Marca a posição do jogador

    for linha in labirinto_visual:
        print("".join(linha))  # Imprime cada linha do labirinto
