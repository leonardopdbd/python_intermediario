# jogador.py
from pynput.keyboard import Key, Listener

def iniciar_jogador():
    """Inicializa a posição e a pontuação do jogador."""
    return {'posicao': (0, 0), 'pontuacao': 0}

def mover(direcao: str, jogador: dict, labirinto: list):
    """Move o jogador no labirinto se possível."""
    y, x = jogador['posicao']
    
    if direcao == 'w':  # para cima
        nova_posicao = (y - 1, x)
    elif direcao == 's':  # para baixo
        nova_posicao = (y + 1, x)
    elif direcao == 'a':  # esquerda
        nova_posicao = (y, x - 1)
    elif direcao == 'd':  # direita
        nova_posicao = (y, x + 1)
    else:
        return  # Direção inválida

    # Verificar se a nova posição é um espaço vazio
    if labirinto[nova_posicao[0]][nova_posicao[1]] == ' ':
        jogador['posicao'] = nova_posicao
    elif labirinto[nova_posicao[0]][nova_posicao[1]] == '#':
        print("Você colidiu com uma parede! Game Over.")
        return False  # Retorna False se colidir com a parede

    return True  # Retorna True se o movimento for bem-sucedido

def pontuar(jogador: dict):
    """Atualiza a pontuação do jogador."""
    jogador['pontuacao'] += 10

def checar_vitoria(jogador: dict, labirinto: list):
    """Verifica se o jogador chegou ao final do labirinto."""
    # Defina a posição de vitória (pode ser a última linha ou coluna, dependendo do seu labirinto)
    if jogador['posicao'] == (len(labirinto) - 1, len(labirinto[0]) - 1): 
        print("Você venceu! Parabéns!")
        return True
    return False
