# __init__.py


from .jogador import iniciar_jogador, mover, pontuar
from .utils import imprime_instrucoes
from .labirinto import criar_labirinto, imprimir_labirinto




__all__ = [
    "criar_labirinto",
    "imprimir_labirinto",
    "iniciar_jogador",
    "mover",
    "pontuar",
    "imprime_instrucoes",
    "imprime_menu"
]

__version__ = "0.1.0"
